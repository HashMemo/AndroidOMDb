package com.example.asus.imdb;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;


//Class containing the important part of Movie
public class Movie {
    private String title;
    private String year;
    private String imageURL;
    private String genre;
    private String id;

    public String getId() {
        return id;
    }

    public String getGenre() {
        return genre;
    }

    public String getTitle() {
        return title;
    }

    public String getYear() {
        return year;
    }

    public String getImageURL() {
        return imageURL;
    }

    public Movie (String title, String year, String imageURL, String genre, String id){
        this.title = title;
        this.year = year;
        this.imageURL = imageURL;
        this.genre = genre;
        this.id = id;
    }
}
