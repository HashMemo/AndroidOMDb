package com.example.asus.imdb;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.support.v7.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    List<String> yearList;
    ArrayAdapter<String> adapter;
    ArrayList<Movie> listOfMovies = new ArrayList<>();
    Context context;
    String textTitle;
    Spinner yearChooser;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Initialization of spinner and searchView in ActionBar, and init the yearList
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_layout, menu);
        MenuItem search = menu.findItem(R.id.search_view_bar);
        MenuItem spinner = menu.findItem(R.id.spinner_bar);
        yearList = new ArrayList<String>();
        yearChooser = (Spinner)spinner.getActionView();
        SearchView searchViewBar = (SearchView) search.getActionView();
        //SearchView button enabling and setting mav width
        searchViewBar.setSubmitButtonEnabled(true);
        searchViewBar.setMaxWidth(Integer.MAX_VALUE-150);
        searchViewBar.setQueryHint("Title");
        //Setting the years in spinner from 2016 to 1980. The first choose is empty;
        int minYear = 1980;
        yearList.add("");
        for (int year = 2016; year>=minYear; year--){
            yearList.add(String.valueOf(year));
        }
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, yearList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearChooser.setAdapter(adapter);

        searchViewBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //Clearing the listOfMovies and begin search for movie by title and the year
                textTitle = query;
                listOfMovies.clear();
                Connection connection = new Connection();
                connection.execute(textTitle, yearChooser.getSelectedItem().toString());
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initialize ListView
        listView = (ListView)findViewById(R.id.listview);
        context = this;

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                //Opening the movie information to dialog
                if(listOfMovies!=null){
                    for(int i=0; i<listOfMovies.size(); i++){
                        //Getting information from TextViews at the Item
                        String title = ((TextView) view.findViewById(R.id.txtTitle)).getText().toString();
                        String year = ((TextView) view.findViewById(R.id.txtYear)).getText().toString();
                        String genre = ((TextView) view.findViewById(R.id.txtGenre)).getText().toString();
                        //Comparing of values in the TextViews and in the listOfMovies
                        if(listOfMovies.get(i).getTitle().equals(title) && listOfMovies.get(i).getYear().equals(year)
                                && listOfMovies.get(i).getGenre().equals(genre)){
                            String id = listOfMovies.get(i).getId();
                            //Opening connection to server and send id of the movie
                            HttpHandler httpHandler = new HttpHandler();
                            try {
                                String urlInfo = "http://www.omdbapi.com/?i="+id;
                                String urlConnection = httpHandler.makeServiceCall(urlInfo);
                                if(urlConnection!=null) {
                                    JSONObject last = new JSONObject(urlConnection);
                                    //Setting received values in Strings
                                    String runtime = last.getString("Runtime");
                                    String director = last.getString("Director");
                                    String writer = last.getString("Writer");
                                    String country = last.getString("Country");
                                    String awards = last.getString("Awards");
                                    String actors = last.getString("Actors");
                                    String plot = last.getString("Plot");
                                    //Building AlertDialog for showing the results
                                    AlertDialog.Builder alert = new AlertDialog.Builder(context);
                                    LinearLayout linearLayout = new LinearLayout(context);
                                    linearLayout.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                            ViewGroup.LayoutParams.WRAP_CONTENT,
                                            ViewGroup.LayoutParams.WRAP_CONTENT
                                    );
                                    params.setMargins(30, 15, 15, 20);
                                    TextView tvRuntime = new TextView(context);
                                    TextView tvDirector = new TextView(context);
                                    TextView tvWriter = new TextView(context);
                                    TextView tvCountry = new TextView(context);
                                    TextView tvAwards = new TextView(context);
                                    TextView tvActors = new TextView(context);
                                    TextView tvPlot = new TextView(context);

                                    if (!runtime.equals("N/A")) {
                                        tvRuntime.setText("Runtime: " + runtime);
                                        linearLayout.addView(tvRuntime);
                                        tvRuntime.setLayoutParams(params);
                                    }
                                    if (!director.equals("N/A")) {
                                        tvDirector.setText("Director: " + director);
                                        linearLayout.addView(tvDirector);
                                        tvDirector.setLayoutParams(params);
                                    }
                                    if (!writer.equals("N/A")) {
                                        tvWriter.setText("Writer: " + writer);
                                        linearLayout.addView(tvWriter);
                                        tvWriter.setLayoutParams(params);
                                    }
                                    if (!country.equals("N/A")) {
                                        tvCountry.setText("Country: " + country);
                                        linearLayout.addView(tvCountry);
                                        tvCountry.setLayoutParams(params);
                                    }
                                    if (!awards.equals("N/A")) {
                                        tvAwards.setText("Awards: " + awards);
                                        linearLayout.addView(tvAwards);
                                        tvAwards.setLayoutParams(params);
                                    }
                                    if (!actors.equals("N/A")) {
                                        tvActors.setText("Actors: " + actors);
                                        linearLayout.addView(tvActors);
                                        tvActors.setLayoutParams(params);
                                    }
                                    if (!plot.equals("N/A")) {
                                        tvPlot.setText("Plot: " + plot);
                                        linearLayout.addView(tvPlot);
                                        tvPlot.setLayoutParams(params);
                                    }
                                    alert.setTitle(listOfMovies.get(i).getTitle());
                                    alert.setView(linearLayout);
                                    alert.setNeutralButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            dialogInterface.cancel();
                                        }
                                    });
                                    alert.show();
                                }else{
                                    showDialog("Can't get results","There is an error");
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();

                            }
                        }
                    }
                }
            }
        });

    }
    public void showDialog(String title, String Message) {
        //Alert dialog for showing errors and no result
        AlertDialog.Builder alert = new AlertDialog.Builder(context);
        alert.setTitle(title);
        alert.setMessage(Message);
        alert.setNeutralButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        alert.show();
    }
    private class Connection extends AsyncTask<String, Void, Void>{
        //Connection is AsyncTask that communicate with OMDB API
        private ProgressDialog pdia;
        @Override
        protected void onPreExecute() {
            //Creating loading dialog
            pdia = new ProgressDialog(context);
            pdia.setMessage("Loading...");
            pdia.show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //Dismissing dialog when done
            pdia.dismiss();
            //Checking if listOfMovies is empty
            if(listOfMovies.isEmpty()){
                showDialog("No Results", "There is no results about " + textTitle);
            }else {
                //Setting listOfMovies to CustomAdapter(MovieAdapter), then setting adapter to ListView
                MovieAdapter movieAdapter = new MovieAdapter(getApplicationContext(), listOfMovies);
                listView.setAdapter(movieAdapter);
            }
        }
        @Override
        protected Void doInBackground(String... strings) {
            //Openning connection by HttpConnection
            HttpHandler httpHandler = new HttpHandler();
            //Send information to server
            String url = "http://www.omdbapi.com/?s="+strings[0]+"&y="+strings[1];
            String jsonCon = httpHandler.makeServiceCall(url);
            if(jsonCon != null){
                try {
                    //Parsing the received String into JsonObject, then getting JsonArray from JsonObject
                    JSONObject jsonObject = new JSONObject(jsonCon);
                    JSONArray movies = jsonObject.getJSONArray("Search");
                    for (int i = 0; i < movies.length(); i++) {
                        JSONObject movie = movies.getJSONObject(i);
                        //Getting values from server to and saving them in string
                        String title = movie.getString("Title");
                        String year = movie.getString("Year");
                        String id = movie.getString("imdbID");
                        String poster = movie.getString("Poster");
                        //Opening new connection to get Genre of Movie
                        String urlInfo = "http://www.omdbapi.com/?i=" + id;
                        String urlConnection = httpHandler.makeServiceCall(urlInfo);
                        JSONObject last = new JSONObject(urlConnection);
                        String genre = last.getString("Genre");
                        //Parsing movie information to custom class named Movie
                        Movie newMovie = new Movie(title, year, poster, genre, id);
                        //Add the newMovie to listOfMovies
                        listOfMovies.add(newMovie);
                    }
                }catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
    }
}
