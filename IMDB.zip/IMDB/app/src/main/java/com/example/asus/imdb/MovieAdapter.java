package com.example.asus.imdb;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

//MovieAdapter is Customized ArrayAdapter of Movies
public class MovieAdapter extends ArrayAdapter<Movie> {

    public MovieAdapter(Context context, ArrayList<Movie> movies) {
        super(context, 0, movies);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Movie movie = getItem(position);
        //Getting the view
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_layout,parent,false);
        }
        //Implementing of TextViews and ImageView
        TextView tvTitle = (TextView) convertView.findViewById(R.id.txtTitle);
        TextView tvYear = (TextView) convertView.findViewById(R.id.txtYear);
        TextView tvGenre = (TextView) convertView.findViewById(R.id.txtGenre);
        ImageView imagePoster = (ImageView) convertView.findViewById(R.id.imagePoster);

        //Setting the values to defined objects
        tvTitle.setText(movie.getTitle());
        tvYear.setText(movie.getYear());
        tvGenre.setText(movie.getGenre());
        if(movie.getImageURL()!="N/A")
            Picasso.with(getContext()).load(movie.getImageURL()).into(imagePoster);

        return convertView;
    }
}
